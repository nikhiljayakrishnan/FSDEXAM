﻿namespace ExamStudent.Modal
{
    public class AddStudentdtl
    {
        public int id { get; set; }
        public string studentName { get; set; }
        public int courseID { get; set; }
        public string password { get; set; }

    }
}
