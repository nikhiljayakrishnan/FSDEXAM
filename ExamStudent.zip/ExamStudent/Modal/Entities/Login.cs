﻿namespace ExamStudent.Modal.Entities
{
    public class Login
    {
    }
}
