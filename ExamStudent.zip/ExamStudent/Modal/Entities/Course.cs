﻿namespace ExamStudent.Modal.Entities
{
    public class Course
    {
        public int ID { get; set; }
        public string? CourseName { get; set; }
    }
}
