﻿namespace ExamStudent.Modal.Entities
{
    public class Student
    {

        public int id { get; set; }
        public string studentName { get; set; }
        public int courseID { get; set; }
        public string password { get; set; }
    }
}
