﻿namespace ExamStudent.Modal
{
    public class UpdateStudent
    {
        public required int id { get; set; }
        public required string studentName { get; set; }
        public int courseID { get; set; }
        public string password { get; set; }



    }
}
