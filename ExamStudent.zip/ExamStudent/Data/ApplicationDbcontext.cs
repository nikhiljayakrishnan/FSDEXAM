﻿

using ExamStudent.Modal.Entities;
using Microsoft.EntityFrameworkCore;
using System.Data;

namespace ExamStudent.Data
{
    public class ApplicationDbcontext : DbContext
    {
        public ApplicationDbcontext(DbContextOptions<ApplicationDbcontext> options) : base(options) 
        {
            
        }
        public DbSet<Student> Students { get; set; }

    }
    
}
