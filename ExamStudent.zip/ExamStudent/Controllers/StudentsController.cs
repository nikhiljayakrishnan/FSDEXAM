﻿using ExamStudent.Data;
using ExamStudent.Modal;
using ExamStudent.Modal.Entities;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;

namespace ExamStudent.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class StudentsController : ControllerBase
    {
        private readonly ApplicationDbcontext dbcontext;
        public StudentsController(ApplicationDbcontext dbcontext)
        {
            this.dbcontext = dbcontext;
        }

        [HttpGet]
        public IActionResult GetAllEmployess()
        {
            var allStudents = dbcontext.Students.ToList();
            return Ok(allStudents);

        }


        [HttpPost]
        public IActionResult AddStudent(Modal.AddStudentdtl addStudentdtl)
        {
            var studentEntity = new Student()
            {
                id = addStudentdtl.id,
                studentName = addStudentdtl.studentName,
                courseID = addStudentdtl.courseID,
                password = addStudentdtl.password,
            };
            dbcontext.Students.Add(studentEntity);
            dbcontext.SaveChanges();
            return Ok(studentEntity);

        }


        [HttpPost("Login")]
        public ActionResult<Student> Login(string studentName, string password)
        {
            var user = dbcontext.Students.FirstOrDefault(x => x.studentName == studentName && x.password == password);
            if (user == null)
            {
                return NotFound();
            }
            return user;
        }


        [HttpGet]
        [Route("{id:int}")]
        public IActionResult GetEmployessbyid(int id)
        {
            var student = dbcontext.Students.Find(id);
            if (student == null)
            {
                return NotFound();
            }
            return Ok(student);

        }

        [HttpPut]
        [Route("{id:int}")]
        public IActionResult UpadteEmployee(int id, UpdateStudent updateStudent)
        {
            var student = dbcontext.Students.Find(id);
            if (student == null)
            {
                return NotFound();
            }

 
            //student.studentName = updateStudent.studentName;
            student.courseID = updateStudent.courseID;
            //student.password = updateStudent.password;
            dbcontext.SaveChanges();
            return Ok(student);

        }

    }
}
